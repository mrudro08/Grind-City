import "server-only";

/**
 * Sliding-window rate limiter kept in process memory.
 * Good for a single Node instance (Hostinger Node app / small VPS). On a multi-instance or
 * serverless deploy swap the Map for Upstash Redis / Vercel KV — the interface stays the same.
 */
const buckets = new Map<string, number[]>();
const SWEEP_EVERY = 5 * 60 * 1000;
let lastSweep = Date.now();

export function rateLimit(key: string, limit = 5, windowMs = 60_000): { ok: boolean; retryAfter: number } {
  const now = Date.now();
  if (now - lastSweep > SWEEP_EVERY) {
    for (const [k, hits] of buckets) if (hits.every((t) => now - t > windowMs)) buckets.delete(k);
    lastSweep = now;
  }
  const hits = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= limit) {
    return { ok: false, retryAfter: Math.ceil((windowMs - (now - hits[0])) / 1000) };
  }
  hits.push(now);
  buckets.set(key, hits);
  return { ok: true, retryAfter: 0 };
}

export function clientIp(req: Request) {
  const fwd = req.headers.get("x-forwarded-for");
  return (fwd ? fwd.split(",")[0] : req.headers.get("x-real-ip")) ?? "unknown";
}
