import { cache, createElement } from "react";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { site } from "@/data/site";
import type { PopupEvent } from "@/data/events";
import type { Faq } from "@/data/content";
import { env } from "@/env";
import { sanityFetch } from "@/sanity/client";
import { pageSeoQuery, siteSettingsQuery } from "@/sanity/queries";
import { sanityImageUrl } from "@/sanity/image";
import type { PageSeo, SiteSettings } from "@/sanity/types";

/* ------------------------------------------------------------------ */
/*  Site settings (Sanity singleton → static fallback)                 */
/* ------------------------------------------------------------------ */

/** De-duplicated per request (layout + generateMetadata both call it). */
export const getSiteSettings = cache(async (): Promise<SiteSettings | null> => {
  return sanityFetch<SiteSettings>(siteSettingsQuery, {}, ["siteSettings"]);
});

/* ------------------------------------------------------------------ */
/*  Per-page metadata                                                  */
/* ------------------------------------------------------------------ */

type Fallback = { title: string; description: string; path: string; image?: string; keywords?: string[]; noIndex?: boolean };

/**
 * Builds the full <head> metadata for a page.
 * Order of precedence for every field: page.seo (Sanity) → siteSettings.seo (Sanity) → static fallback.
 * Editors control meta title, description, keywords, OG title/description/image, canonical and
 * index/follow from the Studio; developers only supply sensible defaults here.
 */
export async function buildMetadata(slug: string, fallback: Fallback): Promise<Metadata> {
  const [page, settings] = await Promise.all([sanityFetch<PageSeo>(pageSeoQuery, { slug }, [`page:${slug}`]), getSiteSettings()]);
  const p = page?.seo ?? {};
  const s = settings?.seo ?? {};
  const siteName = settings?.siteName ?? site.name;

  const title = p.metaTitle ?? fallback.title;
  const description = p.metaDescription ?? fallback.description;
  const keywords = p.keywords?.length ? p.keywords : (s.keywords?.length ? s.keywords : fallback.keywords);
  const ogTitle = p.ogTitle ?? title;
  const ogDescription = p.ogDescription ?? description;
  const ogImageUrl = sanityImageUrl(p.ogImage) ?? sanityImageUrl(s.ogImage) ?? fallback.image ?? "/images/hero-home.webp";
  const ogImageAlt = p.ogImage?.alt ?? s.ogImage?.alt ?? siteName;
  const canonical = p.canonicalUrl ?? fallback.path;
  const noIndex = p.noIndex ?? fallback.noIndex ?? false;
  const noFollow = p.noFollow ?? false;

  return {
    title,
    description,
    keywords,
    alternates: { canonical },
    robots: { index: !noIndex, follow: !noFollow, googleBot: { index: !noIndex, follow: !noFollow, "max-image-preview": "large", "max-snippet": -1 } },
    openGraph: {
      type: "website",
      siteName,
      locale: "en_US",
      url: fallback.path,
      title: ogTitle,
      description: ogDescription,
      images: [{ url: ogImageUrl, width: 1200, height: 630, alt: ogImageAlt }],
    },
    twitter: {
      card: "summary_large_image",
      title: ogTitle,
      description: ogDescription,
      images: [ogImageUrl],
      ...(settings?.twitterHandle ? { site: settings.twitterHandle, creator: settings.twitterHandle } : {}),
    },
  };
}

/** Root metadata (template + verification) — page metadata merges on top. */
export async function rootMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  const siteName = settings?.siteName ?? site.name;
  const template = settings?.titleTemplate ?? `%s · ${siteName}`;
  return {
    metadataBase: new URL(env.NEXT_PUBLIC_SITE_URL),
    title: { default: settings?.seo?.metaTitle ?? `${siteName} — The car wash that shows up`, template },
    description: settings?.seo?.metaDescription ?? settings?.description ?? site.description,
    applicationName: siteName,
    keywords: settings?.seo?.keywords,
    formatDetection: { telephone: true, email: true, address: false },
    ...(settings?.googleSiteVerification ? { verification: { google: settings.googleSiteVerification } } : {}),
  };
}

/* ------------------------------------------------------------------ */
/*  JSON-LD                                                            */
/* ------------------------------------------------------------------ */

/** Inline JSON-LD with the per-request CSP nonce. Serialises safely (no `</script>` break-out). */
export async function JsonLd({ data }: { data: Record<string, unknown> | Record<string, unknown>[] }) {
  const nonce = (await headers()).get("x-nonce") ?? undefined;
  const json = JSON.stringify(data).replace(/</g, "\\u003c");
  return createElement("script", { type: "application/ld+json", nonce, dangerouslySetInnerHTML: { __html: json } });
}

export function localBusinessLd(settings?: SiteSettings | null) {
  const url = env.NEXT_PUBLIC_SITE_URL;
  const name = settings?.siteName ?? site.name;
  const social = settings?.social ?? site.social;
  const rating = settings?.rating?.value && settings?.rating?.count ? settings.rating : site.rating;
  return {
    "@context": "https://schema.org",
    "@type": "AutoWash",
    "@id": `${url}/#business`,
    name,
    url,
    telephone: settings?.phone ?? site.phone,
    email: settings?.email ?? site.email,
    image: `${url}/images/hero-home.webp`,
    slogan: settings?.tagline ?? site.tagline,
    description: settings?.description ?? site.description,
    areaServed: { "@type": "City", name: "Memphis", containedInPlace: { "@type": "State", name: "Tennessee" } },
    address: { "@type": "PostalAddress", addressLocality: settings?.city ?? site.city, addressRegion: settings?.region ?? site.region, addressCountry: "US" },
    priceRange: "$$",
    sameAs: Object.values(social).filter(Boolean),
    aggregateRating: { "@type": "AggregateRating", ratingValue: rating.value, reviewCount: rating.count, bestRating: 5 },
  };
}

export function eventLd(e: PopupEvent) {
  const url = env.NEXT_PUBLIC_SITE_URL;
  return {
    "@context": "https://schema.org",
    "@type": "Event",
    name: `Grind City Detail pop-up — ${e.lot}`,
    startDate: e.start,
    endDate: e.end,
    eventStatus: "https://schema.org/EventScheduled",
    eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
    location: { "@type": "Place", name: e.lot, address: e.address },
    organizer: { "@id": `${url}/#business` },
    offers: { "@type": "Offer", availability: "https://schema.org/InStock", url: `${url}/pop-up` },
  };
}

export function serviceLd(name: string, description: string, path: string) {
  const url = env.NEXT_PUBLIC_SITE_URL;
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name,
    description,
    serviceType: name,
    provider: { "@id": `${url}/#business` },
    areaServed: "Memphis, TN",
    url: `${url}${path}`,
  };
}

export function faqLd(items: Faq[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
  };
}

export function breadcrumbLd(items: { name: string; path: string }[]) {
  const url = env.NEXT_PUBLIC_SITE_URL;
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({ "@type": "ListItem", position: i + 1, name: it.name, item: `${url}${it.path}` })),
  };
}
