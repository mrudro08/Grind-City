import { z } from "zod";

/** Shared by the client forms (instant validation) and /api/lead (authoritative validation). */

const trimmed = (max: number) => z.string().trim().max(max);
const phone = z
  .string()
  .trim()
  .min(7, "Enter a phone number")
  .max(25)
  .regex(/^[+()\d\s.-]+$/, "Digits only, please")
  .refine((v) => v.replace(/\D/g, "").length >= 10, "Enter a 10-digit number");
const email = z.email("Enter a valid email").max(254);
const name = trimmed(80).min(2, "Enter your name");

const base = {
  /** Honeypot — real users never fill this. */
  website: z.string().max(0).optional().or(z.literal("")),
  page: trimmed(200).optional(),
};

export const popupAlertsSchema = z.object({
  type: z.literal("popup-alerts"),
  name,
  phone,
  email: email.optional().or(z.literal("")),
  ...base,
});

export const fleetQuoteSchema = z.object({
  type: z.literal("fleet-quote"),
  company: trimmed(120).min(2, "Enter your company"),
  location: trimmed(120).optional().or(z.literal("")),
  vehicles: trimmed(20).optional().or(z.literal("")),
  types: trimmed(40).optional().or(z.literal("")),
  frequency: trimmed(20).optional().or(z.literal("")),
  name,
  phone,
  email: email.optional().or(z.literal("")),
  ...base,
});

export const employerDaySchema = z.object({
  type: z.literal("employer-day"),
  company: trimmed(120).min(2, "Enter your company"),
  teamSize: trimmed(20).optional().or(z.literal("")),
  date: trimmed(20).optional().or(z.literal("")),
  zip: trimmed(12).optional().or(z.literal("")),
  pay: trimmed(30).optional().or(z.literal("")),
  name,
  phone,
  email: email.optional().or(z.literal("")),
  ...base,
});

export const leadSchema = z.discriminatedUnion("type", [popupAlertsSchema, fleetQuoteSchema, employerDaySchema]);
export type Lead = z.infer<typeof leadSchema>;
export type LeadType = Lead["type"];

export const leadLabels: Record<LeadType, string> = {
  "popup-alerts": "Pop-up alerts signup",
  "fleet-quote": "Fleet quote request",
  "employer-day": "Employee Appreciation Day request",
};

/** Flattens zod issues to { field: message } for inline form errors. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
