"use client";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import { ScrambleTextPlugin } from "gsap/ScrambleTextPlugin";

let registered = false;
export function registerGsap() {
  if (registered || typeof window === "undefined") return gsap;
  gsap.registerPlugin(ScrollTrigger, SplitText, ScrambleTextPlugin);
  gsap.defaults({ ease: "power3.out", duration: 0.8 });
  registered = true;
  return gsap;
}

export const EASE = "power3.out";
export const DUR = 0.8;
export const STAGGER = 0.06;
export const SCRAMBLE_CHARS = "/\\_-=+<>#";

export function prefersReducedMotion() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function isDesktop() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(min-width: 1024px) and (hover: hover)").matches;
}

export { gsap, ScrollTrigger, SplitText };
