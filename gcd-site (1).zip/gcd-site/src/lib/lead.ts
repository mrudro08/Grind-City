import type { Lead } from "@/lib/lead-schema";

export type LeadResult = { ok: true } | { ok: false; status: number; message: string };

/** Posts a validated lead to the API. Never throws. */
export async function postLead(payload: Lead): Promise<LeadResult> {
  try {
    const res = await fetch("/api/lead", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, page: typeof window !== "undefined" ? window.location.pathname : "" }),
    });
    if (res.ok) return { ok: true };
    const message = res.status === 429 ? "Too many tries — give it a minute." : "Something went wrong. Call or text us instead.";
    return { ok: false, status: res.status, message };
  } catch {
    return { ok: false, status: 0, message: "You look offline. Try again in a moment." };
  }
}
