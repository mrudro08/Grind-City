import { z } from "zod";

/**
 * Validated environment. Public vars are inlined into the client bundle; everything else is
 * server-only. Sanity is optional — without a project ID the site renders from the static
 * data layer and the default SEO in src/data/site.ts.
 */
const schema = z.object({
  NEXT_PUBLIC_SITE_URL: z.url().default("https://grindcitydetail.com"),
  NEXT_PUBLIC_SANITY_PROJECT_ID: z.string().regex(/^[a-z0-9-]+$/).optional(),
  NEXT_PUBLIC_SANITY_DATASET: z.string().default("production"),
  NEXT_PUBLIC_SANITY_API_VERSION: z.string().default("2026-10-01"),
  SANITY_API_READ_TOKEN: z.string().optional(), // only needed for private datasets / drafts
  SANITY_API_WRITE_TOKEN: z.string().optional(), // lets /api/lead store leads as Sanity documents
  SANITY_REVALIDATE_SECRET: z.string().min(16).optional(),
  LEAD_WEBHOOK_URL: z.url().optional(), // Zapier / Make / CRM
  RESEND_API_KEY: z.string().optional(), // email notifications via Resend
  LEAD_TO_EMAIL: z.email().optional(),
  LEAD_FROM_EMAIL: z.email().optional(),
});

const parsed = schema.safeParse({
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
  NEXT_PUBLIC_SANITY_PROJECT_ID: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID,
  NEXT_PUBLIC_SANITY_DATASET: process.env.NEXT_PUBLIC_SANITY_DATASET,
  NEXT_PUBLIC_SANITY_API_VERSION: process.env.NEXT_PUBLIC_SANITY_API_VERSION,
  SANITY_API_READ_TOKEN: process.env.SANITY_API_READ_TOKEN,
  SANITY_API_WRITE_TOKEN: process.env.SANITY_API_WRITE_TOKEN,
  SANITY_REVALIDATE_SECRET: process.env.SANITY_REVALIDATE_SECRET,
  LEAD_WEBHOOK_URL: process.env.LEAD_WEBHOOK_URL,
  RESEND_API_KEY: process.env.RESEND_API_KEY,
  LEAD_TO_EMAIL: process.env.LEAD_TO_EMAIL,
  LEAD_FROM_EMAIL: process.env.LEAD_FROM_EMAIL,
});

if (!parsed.success) {
  // Fail fast with a readable message instead of a cryptic runtime error later.
  throw new Error("Invalid environment variables:\n" + JSON.stringify(parsed.error.flatten().fieldErrors, null, 2));
}

export const env = parsed.data;
export const sanityEnabled = Boolean(env.NEXT_PUBLIC_SANITY_PROJECT_ID);
