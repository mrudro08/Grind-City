"use client";
import Link from "next/link";
import { useRef, type ComponentProps, type ReactNode } from "react";
import { useGSAP } from "@gsap/react";
import { cn } from "@/lib/cn";
import { useScramble } from "@/components/motion/useScramble";
import { registerGsap, isDesktop, prefersReducedMotion } from "@/lib/gsap";

type Variant = "primary" | "dark" | "outline" | "outline-dark";

type Props = {
  variant?: Variant;
  href?: string;
  children: ReactNode;
  arrow?: boolean;
  className?: string;
  full?: boolean;
  magnetic?: boolean;
  /** Shows a spinner + shimmer and disables the control. */
  loading?: boolean;
} & Omit<ComponentProps<"button">, "children">;

const styles: Record<Variant, { stroke: string; fill: string; text: string; hoverFill: string }> = {
  primary: { stroke: "bg-orange-light", fill: "bg-orange", text: "text-white", hoverFill: "bg-[#ff7f36]" },
  dark: { stroke: "bg-smoke", fill: "bg-ink", text: "text-white", hoverFill: "bg-orange" },
  outline: { stroke: "bg-white", fill: "bg-white/0", text: "text-white", hoverFill: "bg-white/15" },
  "outline-dark": { stroke: "bg-ink", fill: "bg-ink/0", text: "text-ink", hoverFill: "bg-ink/8" },
};

/**
 * Corner-cut button. Outer = 1.5px stroke colour, inner = fill.
 * Hover: fill sweeps in from the cut corner, label scrambles, arrow nudges right, slight lift. Magnetic pull on desktop.
 */
export function Button({ variant = "primary", href, children, arrow = true, className, full, magnetic = false, loading = false, ...rest }: Props) {
  const s = styles[variant];
  const { ref: labelRef, onMouseEnter: scramble } = useScramble<HTMLSpanElement>();
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const el = root.current;
      if (!el || !isDesktop() || prefersReducedMotion()) return;
      const gsap = registerGsap();
      const fill = el.querySelector<HTMLElement>("[data-fill]");
      const arrowEl = el.querySelector<HTMLElement>("[data-arrow]");
      const xTo = gsap.quickTo(el, "x", { duration: 0.4, ease: "power3" });
      const yTo = gsap.quickTo(el, "y", { duration: 0.4, ease: "power3" });

      const enter = () => {
        gsap.to(fill, { xPercent: 0, duration: 0.45, ease: "power3.out", overwrite: true });
        gsap.to(arrowEl, { x: 6, duration: 0.35, ease: "power3.out" });
        gsap.to(el, { y: -2, duration: 0.3 });
      };
      const leave = () => {
        gsap.to(fill, { xPercent: -101, duration: 0.45, ease: "power3.inOut", overwrite: true });
        gsap.to(arrowEl, { x: 0, duration: 0.35 });
        gsap.to(el, { y: 0, duration: 0.3 });
        if (magnetic) {
          xTo(0);
          yTo(0);
        }
      };
      const move = (e: MouseEvent) => {
        if (!magnetic) return;
        const r = el.getBoundingClientRect();
        xTo(((e.clientX - r.left) / r.width - 0.5) * 12);
        yTo(((e.clientY - r.top) / r.height - 0.5) * 12);
      };
      el.addEventListener("mouseenter", enter);
      el.addEventListener("mouseleave", leave);
      el.addEventListener("mousemove", move);
      return () => {
        el.removeEventListener("mouseenter", enter);
        el.removeEventListener("mouseleave", leave);
        el.removeEventListener("mousemove", move);
      };
    },
    { scope: root },
  );

  const content = (
    <span className={cn("cut-sm relative flex items-center justify-center gap-3 overflow-hidden px-8 py-[17px]", s.fill)}>
      <span data-fill className={cn("absolute inset-0 -translate-x-[101%]", s.hoverFill)} aria-hidden />
      {loading && <span className="btn-shimmer absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent" aria-hidden />}
      <span className={cn("cut-sm cut-stroke", s.stroke)} aria-hidden />
      <span ref={labelRef} className={cn("label relative text-[13px] tracking-[0.12em] transition-opacity duration-300", s.text, loading && "opacity-70")}>
        {children}
      </span>
      {loading ? (
        <span className={cn("spinner relative h-4 w-4 rounded-full border-2 border-current border-t-transparent", s.text)} aria-hidden />
      ) : (
        arrow && (
          <span data-arrow className={cn("relative text-base leading-none", s.text)} aria-hidden>
            →
          </span>
        )
      )}
    </span>
  );

  const cls = cn("group inline-block select-none transition-transform active:scale-[0.97] disabled:cursor-wait disabled:active:scale-100", full && "w-full", className);

  if (href) {
    return (
      <Link ref={root as React.Ref<HTMLAnchorElement>} href={href} className={cls} onMouseEnter={scramble}>
        {content}
      </Link>
    );
  }
  return (
    <button ref={root as React.Ref<HTMLButtonElement>} className={cls} onMouseEnter={scramble} aria-busy={loading || undefined} disabled={loading || rest.disabled} {...rest}>
      {content}
    </button>
  );
}
