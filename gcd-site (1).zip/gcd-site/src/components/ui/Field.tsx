"use client";
import { useId, type ComponentProps } from "react";
import { cn } from "@/lib/cn";

type Props = {
  label: string;
  theme?: "dark" | "light";
  as?: "input" | "select";
  options?: string[];
  className?: string;
  error?: string;
  hint?: string;
} & ComponentProps<"input">;

/**
 * Corner-cut form field.
 * Motion: stroke + accent + label colour ease to orange on focus, the slanted accent slides in,
 * the field lifts 1px; an error slides the message in and turns the stroke red with a short shake.
 */
export function Field({ label, theme = "dark", as = "input", options, className, error, hint, ...rest }: Props) {
  const id = useId();
  const errId = `${id}-err`;
  const dark = theme === "dark";
  const strokeIdle = dark ? "bg-white/20" : "bg-[#cfcac2]";
  return (
    <div className={cn("group/field", className)} data-invalid={error ? "" : undefined}>
      <label htmlFor={id} className="group block">
        <span
          className={cn(
            "cut-sm relative flex items-center gap-3 py-2.5 pl-5 pr-4 transition-[background-color,transform] duration-300 ease-out group-focus-within:-translate-y-px",
            dark ? "bg-white/5 group-focus-within:bg-white/10" : "bg-white",
            error && "field-shake",
          )}
        >
          <span className={cn("cut-sm cut-stroke transition-colors duration-300", error ? "bg-red-500" : cn(strokeIdle, "group-focus-within:bg-orange"))} aria-hidden />
          <span
            className={cn(
              "slant absolute left-1.5 top-1/2 h-3.5 w-2.5 -translate-y-1/2 transition-[background-color,transform,opacity] duration-300 ease-out group-focus-within:translate-x-0.5 group-focus-within:scale-y-110",
              error ? "bg-red-500" : cn(dark ? "bg-white/25" : "bg-ink/25", "group-focus-within:bg-orange"),
            )}
            aria-hidden
          />
          <span className="flex min-w-0 flex-1 flex-col gap-0.5">
            <span className={cn("label text-[10px] tracking-[0.14em] transition-colors duration-300", error ? "text-red-400" : cn(dark ? "text-white/50" : "text-ink/50", "group-focus-within:text-orange"))}>{label}</span>
            {as === "select" ? (
              <select
                id={id}
                aria-invalid={!!error || undefined}
                aria-describedby={error ? errId : undefined}
                className={cn("w-full appearance-none bg-transparent text-[15px] outline-none", dark ? "text-white" : "text-ink")}
                {...(rest as ComponentProps<"select">)}
              >
                {options?.map((o) => (
                  <option key={o} value={o} className="text-ink">
                    {o}
                  </option>
                ))}
              </select>
            ) : (
              <input
                id={id}
                aria-invalid={!!error || undefined}
                aria-describedby={error ? errId : undefined}
                className={cn("w-full bg-transparent text-[15px] outline-none placeholder:opacity-45", dark ? "text-white" : "text-ink")}
                {...rest}
              />
            )}
          </span>
          {as === "select" && (
            <span className={cn("text-xs transition-transform duration-300 group-focus-within:rotate-180", dark ? "text-white/60" : "text-ink/60")} aria-hidden>
              ▾
            </span>
          )}
        </span>
      </label>
      <div className={cn("grid transition-[grid-template-rows,opacity] duration-300 ease-out", error || hint ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")} aria-live="polite">
        <div className="overflow-hidden">
          <p id={error ? errId : undefined} className={cn("pt-1.5 pl-1 text-[12px]", error ? "text-red-400" : dark ? "text-white/45" : "text-ink/50")}>
            {error ?? hint}
          </p>
        </div>
      </div>
    </div>
  );
}
