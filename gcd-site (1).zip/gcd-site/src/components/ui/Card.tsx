import type { ReactNode, ElementType } from "react";
import { cn } from "@/lib/cn";

type Props = {
  children: ReactNode;
  className?: string;
  tone?: "dark" | "light" | "orange" | "glass";
  /** stroke colour class, e.g. "bg-white/15" */
  stroke?: string;
  size?: "sm" | "md" | "lg";
  as?: ElementType;
  lift?: boolean;
  id?: string;
};

const tones = {
  dark: { fill: "bg-char text-white", stroke: "bg-white/10" },
  light: { fill: "bg-white text-ink", stroke: "bg-ink/10" },
  orange: { fill: "bg-orange text-ink", stroke: "bg-orange-light" },
  glass: { fill: "bg-ink/70 text-white backdrop-blur-xl", stroke: "bg-white/20" },
};

/** Corner-cut card: outer paints the stroke, inner paints the fill. */
export function Card({ children, className, tone = "dark", stroke, size = "md", as: Tag = "div", lift = false, id }: Props) {
  const t = tones[tone];
  const cut = size === "sm" ? "cut-sm" : size === "lg" ? "cut-lg" : "cut";
  return (
    <Tag id={id} className={cn(cut, "relative block", t.fill, lift && "lift", className)}>
      {children}
      <span className={cn(cut, "cut-stroke", stroke ?? t.stroke)} aria-hidden />
    </Tag>
  );
}
