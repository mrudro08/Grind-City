import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

/** Three slanted logo stripes (white / orange / white). */
export function Stripes({ className, dark = false, size = 36 }: { className?: string; dark?: boolean; size?: number }) {
  const w = size * 0.3;
  const gap = size * 0.08;
  const col = dark ? "bg-ink" : "bg-white";
  return (
    <span className={cn("inline-flex", className)} style={{ height: size, gap }} aria-hidden>
      <span className={cn("slant block", col)} style={{ width: w }} />
      <span className="slant block bg-orange" style={{ width: w }} />
      <span className={cn("slant block", col)} style={{ width: w }} />
    </span>
  );
}

export function Logo({ dark = false, className }: { dark?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <Stripes dark={dark} size={32} />
      <span className="flex flex-col leading-[0.85]">
        <span className={cn("display text-[19px] not-italic font-black italic", dark ? "text-ink" : "text-white")}>Grind City</span>
        <span className="display text-[19px] text-orange">Detail</span>
      </span>
    </span>
  );
}

export function Eyebrow({ children, light = false, dot = false, className }: { children: ReactNode; light?: boolean; dot?: boolean; className?: string }) {
  return (
    <p className={cn("eyebrow flex items-center gap-3", light ? "text-white" : "text-ink", className)}>
      {dot ? <span className="h-2.5 w-2.5 rounded-full bg-orange animate-pulse" aria-hidden /> : <span className="h-[3px] w-7 bg-orange" aria-hidden />}
      {children}
    </p>
  );
}

export function Tag({ children, hot = false, light = false, className }: { children: ReactNode; hot?: boolean; light?: boolean; className?: string }) {
  return (
    <span className={cn("label inline-flex items-center gap-2 px-3 py-1.5", hot ? "bg-orange text-ink" : light ? "bg-white/15 text-white" : "bg-ink text-white", className)}>
      {children}
    </span>
  );
}

export function Stars({ className, dark = false, size = "text-base" }: { className?: string; dark?: boolean; size?: string }) {
  return (
    <span className={cn("font-bold tracking-[0.1em]", size, dark ? "text-ink" : "text-orange", className)} aria-label="5 out of 5 stars">
      ★★★★★
    </span>
  );
}

export function Check({ className }: { className?: string }) {
  return <span className={cn("slant inline-block h-4 w-2.5 shrink-0 bg-orange", className)} aria-hidden />;
}

/** Section wrapper with 1680px content width and consistent padding. */
export function Section({ children, className, id, tone = "dark" }: { children: ReactNode; className?: string; id?: string; tone?: "dark" | "light" | "orange" | "black" }) {
  const bg = { dark: "bg-coal text-white", black: "bg-ink text-white", light: "bg-bone text-ink", orange: "bg-orange text-ink" }[tone];
  return (
    <section id={id} className={cn("relative overflow-hidden", bg, className)}>
      <div className="relative mx-auto w-full max-w-[1680px] px-6 py-20 md:px-10 lg:py-[140px] lg:px-[60px] 3xl:px-0">{children}</div>
    </section>
  );
}

/** Section header: eyebrow + two-line display headline + optional intro on the right. */
export function SectionHeader({ eyebrow, line1, line2, intro, light = false, dot = false, children }: { eyebrow: string; line1?: string; line2: string; intro?: string; light?: boolean; dot?: boolean; children?: ReactNode }) {
  return (
    <div className="mb-12 flex flex-col gap-8 lg:mb-20 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <Eyebrow light={light} dot={dot}>
          {eyebrow}
        </Eyebrow>
        <h2 className={cn("display mt-8 text-[clamp(40px,6vw,72px)]", light ? "text-white" : "text-ink")}>
          {line1 && (
            <>
              {line1}
              <br />
            </>
          )}
          <span className="text-orange">{line2}</span>
        </h2>
      </div>
      {(intro || children) && (
        <div className="flex max-w-[420px] flex-col gap-5">
          {intro && <p className={cn("text-lg leading-[1.55]", light ? "text-white/70" : "text-smoke")}>{intro}</p>}
          {children}
        </div>
      )}
    </div>
  );
}

/** Background pattern layers. */
export function Pattern({ kind, className }: { kind: "dots" | "stripes" | "iso" | "mark"; className?: string }) {
  if (kind === "mark") {
    return (
      <div className={cn("pointer-events-none absolute flex gap-[6%]", className)} aria-hidden>
        <span className="slant block h-full w-[16%] bg-white/[0.035]" />
        <span className="slant block h-full w-[16%] bg-orange/[0.08]" />
        <span className="slant block h-full w-[16%] bg-white/[0.035]" />
      </div>
    );
  }
  const cls = { dots: "pat-dots", stripes: "pat-stripes", iso: "pat-iso" }[kind];
  return <div className={cn("pointer-events-none absolute", cls, className)} aria-hidden />;
}
