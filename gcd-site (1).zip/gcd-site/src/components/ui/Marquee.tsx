"use client";
import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { registerGsap, prefersReducedMotion } from "@/lib/gsap";
import { cn } from "@/lib/cn";

const DEFAULT = ["Grind hard", "Shine harder", "Pop-ups every weekend", "Fleet washing Mon–Thu"];

/** Orange slanted marquee band. Loops seamlessly with GSAP; slows on hover. */
export function Marquee({ items = DEFAULT, tone = "orange", tilt = true, className }: { items?: string[]; tone?: "orange" | "ink"; tilt?: boolean; className?: string }) {
  const track = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      const gsap = registerGsap();
      const el = track.current;
      if (!el || prefersReducedMotion()) return;
      const tween = gsap.to(el, { xPercent: -50, duration: 28, ease: "none", repeat: -1 });
      const slow = () => gsap.to(tween, { timeScale: 0.25, duration: 0.6 });
      const fast = () => gsap.to(tween, { timeScale: 1, duration: 0.6 });
      el.addEventListener("mouseenter", slow);
      el.addEventListener("mouseleave", fast);
      return () => {
        el.removeEventListener("mouseenter", slow);
        el.removeEventListener("mouseleave", fast);
      };
    },
    { scope: track },
  );
  const row = [...items, ...items];
  return (
    <div className={cn("relative z-10 overflow-hidden", tilt && "-my-7 py-7", className)} aria-hidden>
      <div className={cn("overflow-hidden", tone === "orange" ? "bg-orange text-ink" : "bg-ink text-white", tilt && "-rotate-[1.5deg] scale-[1.02]")}>
      <div ref={track} className="flex w-max whitespace-nowrap py-4">
        {row.map((t, i) => (
          <span key={i} className="display flex items-center gap-8 pr-8 text-[clamp(22px,2.4vw,34px)]">
            {t}
            <span className={cn("slant inline-block h-5 w-3", tone === "orange" ? "bg-ink" : "bg-orange")} />
          </span>
        ))}
      </div>
      </div>
    </div>
  );
}
