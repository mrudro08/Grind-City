"use client";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { Honeypot } from "@/components/forms/Honeypot";
import { FormError } from "@/components/forms/FormError";
import { FormSuccess } from "@/components/forms/FormSuccess";
import { useLeadForm } from "@/components/forms/useLeadForm";
import { popupAlertsSchema } from "@/lib/lead-schema";
import { cn } from "@/lib/cn";

type Props = { compact?: boolean; theme?: "dark" | "light"; className?: string };

/** Pop-up alerts signup (name + mobile + optional email). */
export function SignupForm({ compact = false, theme = "dark", className }: Props) {
  const f = useLeadForm(popupAlertsSchema, () => ({ type: "popup-alerts" }));
  const dark = theme === "dark";

  if (f.done) {
    return (
      <div className={cn("cut-sm", dark ? "bg-white/5" : "bg-white", className)}>
        <FormSuccess compact dark={dark} title="You're on" accent="the list." body="We'll text you before each weekend with the lot and hours." onReset={f.reset} />
      </div>
    );
  }

  return (
    <form key={f.key} onSubmit={f.onSubmit} onChange={f.onChange} noValidate className={cn("relative flex flex-col gap-3", className)}>
      <Honeypot />
      <div className={cn("grid gap-3", compact ? "" : "sm:grid-cols-3")}>
        <Field label="Name" name="name" placeholder="Your name" autoComplete="name" theme={theme} error={f.errors.name} />
        <Field label="Mobile" name="phone" type="tel" inputMode="tel" placeholder="(901) 000-0000" autoComplete="tel" theme={theme} error={f.errors.phone} />
        <Field label="Email (optional)" name="email" type="email" inputMode="email" placeholder="you@email.com" autoComplete="email" theme={theme} error={f.errors.email} />
      </div>
      <Button type="submit" full loading={f.busy}>
        {f.busy ? "Sending" : "Text me the next lot"}
      </Button>
      <FormError message={f.status === "error" ? f.message : ""} dark={dark} />
    </form>
  );
}
