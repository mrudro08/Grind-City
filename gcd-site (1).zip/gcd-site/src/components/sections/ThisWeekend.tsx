import Image from "next/image";
import Link from "next/link";
import { thisWeekend, upcoming } from "@/data/events";
import { Section, SectionHeader, Pattern, Tag } from "@/components/ui/Primitives";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/motion/Reveal";
import { ImageReveal } from "@/components/motion/ImageReveal";
import { SignupForm } from "@/components/ui/SignupForm";

function monthDay(label: string) {
  // "Nov 6 – 8" → ["Nov", "6–8"]
  const [m, ...rest] = label.split(" ");
  return [m, rest.join("").replace(/–/g, "–")];
}

export function ThisWeekend() {
  const e = thisWeekend;
  return (
    <Section id="this-weekend" tone="dark">
      <Pattern kind="stripes" className="right-0 top-0 h-full w-[36%] text-white/[0.04]" />
      <Pattern kind="mark" className="-left-[8%] bottom-[-10%] h-[60%] w-[36%]" />
      <SectionHeader eyebrow="Live this weekend" dot light line1="Find us" line2="this weekend." intro="We move every weekend. Here's where the tunnel is parked — and where it's headed next." />

      <div className="grid gap-6 lg:grid-cols-12">
        <ImageReveal className="lg:col-span-7">
          <Card tone="dark" size="lg" className="h-full">
            <div className="relative min-h-[560px] lg:min-h-[640px]">
              <Image src="/images/iso-map.webp" alt={`Map of this weekend's pop-up at ${e.lot}`} fill sizes="(min-width:1024px) 58vw, 100vw" className="object-cover object-top opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/60 to-transparent" aria-hidden />
              <div className="absolute left-7 top-7 flex gap-3">
                <Tag hot>
                  <span className="h-2 w-2 rounded-full bg-ink animate-pulse" aria-hidden /> Live
                </Tag>
                <Tag light>{e.area}</Tag>
              </div>
              <div className="absolute inset-x-0 bottom-0 p-7 lg:p-12">
                <p className="label text-[11px] tracking-[0.14em] text-orange">Fri–Sun · {e.dateLabel}</p>
                <h3 className="display mt-3 text-[clamp(34px,4.4vw,64px)]">
                  {e.lot}, <span className="text-orange">{e.area}</span>
                </h3>
                <p className="mt-3 text-white/70">{e.address}</p>
                <div className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-[14px]">
                  {e.hours.map((h) => (
                    <span key={h.day} className="flex items-center gap-2">
                      <span className="label text-[11px] text-white/50">{h.day}</span>
                      <span className="font-semibold">{h.time}</span>
                    </span>
                  ))}
                </div>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Button href={e.mapUrl}>Get directions</Button>
                  <Button href="/pop-up#upcoming" variant="outline">
                    Add to calendar
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </ImageReveal>

        <div className="flex flex-col lg:col-span-5">
          <p className="label text-[11px] tracking-[0.14em] text-white/50">Upcoming pop-ups</p>
          <Reveal stagger className="mt-2 flex flex-col">
            {upcoming.slice(0, 4).map((u) => {
              const [m, d] = monthDay(u.dateLabel);
              return (
                <Link key={u.slug} href="/pop-up#upcoming" className="group flex items-center gap-6 border-b border-white/10 py-6 transition-colors hover:border-orange/60">
                  <span className="flex w-[72px] shrink-0 flex-col text-center">
                    <span className="label text-[10px] text-orange">{m}</span>
                    <span className="display whitespace-nowrap text-[22px] not-italic">{d}</span>
                  </span>
                  <span className="flex-1">
                    <span className="block text-[18px] font-bold">{u.lot}</span>
                    <span className="block text-[14px] text-white/55">
                      {u.area}, Memphis {u.status === "tentative" && <span className="label ml-2 text-[9px] text-white/40">Tentative</span>}
                    </span>
                  </span>
                  <span className="text-xl text-white/40 transition-all group-hover:translate-x-1 group-hover:text-orange" aria-hidden>
                    ↗
                  </span>
                </Link>
              );
            })}
          </Reveal>
          <Reveal className="mt-auto pt-8">
            <p className="display text-[24px] not-italic">Get a text when we&apos;re near you.</p>
            <div className="mt-4">
              <SignupForm compact />
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
