import { type Review } from "@/data/content";
import { Stars, Tag } from "@/components/ui/Primitives";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/cn";

const catLabel: Record<Review["category"], string> = { "pop-up": "Pop-up", employers: "Workplace", fleet: "Fleet" };

export function ReviewCard({ r, className }: { r: Review; className?: string }) {
  const initials = r.name
    .split(" ")
    .map((n) => n[0])
    .join("");
  return (
    <Card tone="dark" stroke={r.featured ? "bg-orange" : undefined} className={cn("h-full", className)} lift>
      <article className="flex h-full flex-col p-8">
        <div className="flex items-center justify-between">
          <Tag hot={r.featured} light={!r.featured}>
            {catLabel[r.category]}
          </Tag>
          <Stars size="text-xs" />
        </div>
        <blockquote className="mt-8 text-[19px] font-medium leading-[1.45]">“{r.quote}”</blockquote>
        <footer className="mt-auto flex items-center gap-4 pt-8">
          <span className={cn("flex h-11 w-11 items-center justify-center rounded-full text-[12px] font-bold", r.featured ? "bg-orange text-ink" : "bg-white/10 text-white")} aria-hidden>
            {initials}
          </span>
          <span>
            <span className="block text-[15px] font-bold">{r.name}</span>
            <span className="block text-[13px] text-white/50">{r.role}</span>
          </span>
        </footer>
      </article>
    </Card>
  );
}

