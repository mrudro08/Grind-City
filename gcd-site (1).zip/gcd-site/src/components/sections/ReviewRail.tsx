"use client";
import { useRef, useState } from "react";
import type { Review } from "@/data/content";
import { ReviewCard } from "@/components/sections/ReviewCard";
import { Reveal } from "@/components/motion/Reveal";

/** Horizontal scroll-snap rail with progress bar and prev/next controls. */
export function ReviewRail({ items }: { items: Review[] }) {
  const rail = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  const onScroll = () => {
    const el = rail.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    setProgress(max > 0 ? el.scrollLeft / max : 0);
  };
  const go = (dir: 1 | -1) => {
    const el = rail.current;
    if (!el) return;
    const card = el.firstElementChild as HTMLElement | null;
    el.scrollBy({ left: dir * ((card?.offsetWidth ?? 400) + 24), behavior: "smooth" });
  };

  return (
    <Reveal effect="up">
      <div
        ref={rail}
        onScroll={onScroll}
        className="-mx-6 flex snap-x snap-mandatory gap-6 overflow-x-auto px-6 pb-4 md:-mx-10 md:px-10 xl:mx-0 lg:px-[60px] 3xl:px-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {items.map((r) => (
          <div key={r.id} className="w-[86vw] shrink-0 snap-start sm:w-[420px] lg:w-[520px]">
            <ReviewCard r={r} />
          </div>
        ))}
      </div>
      <div className="mt-8 flex items-center gap-6">
        <div className="h-[3px] flex-1 bg-white/10">
          <div className="h-full bg-orange transition-[width] duration-300" style={{ width: `${Math.max(12, progress * 100)}%` }} />
        </div>
        <div className="flex gap-3">
          {([-1, 1] as const).map((d) => (
            <button key={d} type="button" onClick={() => go(d)} aria-label={d === 1 ? "Next reviews" : "Previous reviews"} className="cut-xs bg-white/15 p-px transition-colors hover:bg-orange">
              <span className="cut-xs flex h-12 w-16 items-center justify-center bg-ink text-xl text-white">{d === 1 ? "→" : "←"}</span>
            </button>
          ))}
        </div>
      </div>
    </Reveal>
  );
}
