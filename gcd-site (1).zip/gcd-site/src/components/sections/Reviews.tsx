import Link from "next/link";
import { reviews } from "@/data/content";
import { site } from "@/data/site";
import { Section, SectionHeader, Pattern, Stars } from "@/components/ui/Primitives";
import { Reveal } from "@/components/motion/Reveal";
import { ReviewRail } from "@/components/sections/ReviewRail";

const logos = ["CIRCL", "STACKD", "NORTHLINE", "VELO", "HARBOR", "MERIDIAN"];

export function Reviews({ compact = false }: { compact?: boolean }) {
  return (
    <Section tone="dark">
      <Pattern kind="mark" className="-left-[6%] -top-[6%] h-[50%] w-[30%]" />
      <Pattern kind="stripes" className="right-0 top-0 h-full w-[40%] text-white/[0.04]" />
      <SectionHeader eyebrow="Reviews" light line1="Don't take" line2="our word for it.">
        <div className="flex items-end gap-5">
          <span className="display text-[clamp(56px,6vw,96px)] leading-[0.85]">{site.rating.value}</span>
          <span className="pb-2">
            <Stars />
            <span className="mt-1 block text-[13px] text-white/60">{site.rating.count}+ reviews on Google</span>
            <Link href="/reviews" className="label mt-2 block text-[11px] text-orange hover:underline">
              Read all reviews ↗
            </Link>
          </span>
        </div>
      </SectionHeader>

      <ReviewRail items={compact ? reviews.slice(0, 4) : reviews} />

      <Reveal className="mt-20 flex flex-col gap-6 border-t border-white/10 pt-10 lg:flex-row lg:items-center lg:gap-12">
        <p className="label max-w-[180px] text-[11px] leading-[1.6] text-white/50">Trusted by Memphis employers &amp; fleets</p>
        <div className="flex flex-1 flex-wrap items-center gap-x-12 gap-y-6">
          {logos.map((l) => (
            <span key={l} className="display flex items-center gap-2 text-[18px] not-italic text-white/40">
              <span className="slant inline-block h-4 w-2.5 bg-white/40" aria-hidden />
              {l}
            </span>
          ))}
        </div>
      </Reveal>
    </Section>
  );
}
