"use client";
import Image from "next/image";
import { useState } from "react";
import { reviews, ratingBreakdown, type Review } from "@/data/content";
import { site } from "@/data/site";
import { Section, SectionHeader, Pattern, Stars } from "@/components/ui/Primitives";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Reveal } from "@/components/motion/Reveal";
import { ImageReveal } from "@/components/motion/ImageReveal";
import { SplitReveal } from "@/components/motion/SplitReveal";
import { Counter } from "@/components/motion/Counter";
import { ReviewCard } from "@/components/sections/ReviewCard";
import { cn } from "@/lib/cn";

export function ReviewsArt() {
  return (
    <ImageReveal>
      <div className="relative aspect-square w-full">
        <Image src="/images/emp-you-get.webp" alt="Isometric trophy and hearts beside the Grind City tunnel" fill priority sizes="(min-width:1024px) 40vw, 100vw" className="object-contain" />
      </div>
    </ImageReveal>
  );
}

export function RatingSummary() {
  return (
    <Section tone="light">
      <Pattern kind="dots" className="left-0 top-0 h-full w-[30%] text-ink/[0.08]" />
      <div className="grid gap-8 lg:grid-cols-12 lg:items-center">
        <Reveal className="lg:col-span-4">
          <Card tone="dark" stroke="bg-orange">
            <div className="p-9">
              <Counter value={site.rating.value} decimals={1} className="display block text-[clamp(88px,9vw,140px)] leading-[0.85]" />
              <Stars className="mt-4 block" />
              <p className="mt-3 text-[14px] text-white/60">Based on {site.rating.count}+ Google reviews</p>
              <div className="mt-7">
                <Button href="https://g.page/grindcitydetail" variant="primary">
                  Read on Google
                </Button>
              </div>
            </div>
          </Card>
        </Reveal>
        <Reveal stagger className="flex flex-col gap-4 lg:col-span-5 lg:px-8">
          {ratingBreakdown.map((r) => (
            <div key={r.stars} className="flex items-center gap-4">
              <span className="label w-8 text-[11px] text-ink">{r.stars} ★</span>
              <span className="h-2 flex-1 bg-ink/10">
                <span className="block h-full bg-orange" style={{ width: `${Math.max(r.pct, 1)}%` }} />
              </span>
              <span className="w-10 text-right text-[12px] text-ash">{r.pct}%</span>
            </div>
          ))}
        </Reveal>
        <Reveal stagger className="flex flex-col gap-4 lg:col-span-3">
          {[
            ["Top mention", "“The crew”"],
            ["Most praised", "Speed & detail"],
            ["Repeat customers", "68%"],
          ].map(([k, v]) => (
            <Card key={k} tone="light" size="sm">
              <div className="px-6 py-5">
                <p className="label text-[10px] text-orange">{k}</p>
                <p className="display mt-1 text-[22px] not-italic text-ink">{v}</p>
              </div>
            </Card>
          ))}
        </Reveal>
      </div>
    </Section>
  );
}

const cats: { key: "all" | Review["category"]; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pop-up", label: "Pop-up" },
  { key: "employers", label: "Employers" },
  { key: "fleet", label: "Fleet" },
];

export function AllReviews() {
  const [cat, setCat] = useState<(typeof cats)[number]["key"]>("all");
  const list = cat === "all" ? reviews : reviews.filter((r) => r.category === cat);
  return (
    <Section tone="black">
      <Pattern kind="stripes" className="right-0 top-0 h-full w-[30%] text-white/[0.04]" />
      <SectionHeader eyebrow="All reviews" light line1="Real cars." line2="Real people.">
        <div role="tablist" aria-label="Filter reviews" className="flex flex-wrap gap-2 lg:justify-end">
          {cats.map((c) => (
            <button key={c.key} type="button" role="tab" aria-selected={cat === c.key} onClick={() => setCat(c.key)} className={cn("cut-xs p-px transition-colors", cat === c.key ? "bg-orange" : "bg-white/20 hover:bg-white/60")}>
              <span className={cn("cut-xs label block px-4 py-2.5 text-[11px]", cat === c.key ? "bg-orange text-ink" : "bg-ink text-white")}>{c.label}</span>
            </button>
          ))}
        </div>
      </SectionHeader>
      <div key={cat} className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {list.map((r) => (
          <Reveal key={r.id} effect="up" start="top 95%">
            <ReviewCard r={r} />
          </Reveal>
        ))}
      </div>
      <div className="mt-12 flex justify-center">
        <Button href="https://g.page/grindcitydetail" variant="outline">
          Load more reviews
        </Button>
      </div>
    </Section>
  );
}

export function TellMemphis() {
  return (
    <Section tone="light">
      <Pattern kind="iso" className="right-0 top-0 h-full w-[40%] text-ink/[0.05]" />
      <div className="grid items-center gap-12 lg:grid-cols-12">
        <ImageReveal className="lg:col-span-5">
          <Card tone="light" size="lg">
            <div className="relative aspect-[4/3]">
              <Image src="/images/iso-tunnel.webp" alt="Isometric view of the Grind City tunnel with a car rolling out" fill sizes="(min-width:1024px) 40vw, 100vw" className="object-cover" />
            </div>
          </Card>
        </ImageReveal>
        <div className="lg:col-span-6 lg:col-start-7">
          <p className="eyebrow flex items-center gap-3 text-ink">
            <span className="h-[3px] w-7 bg-orange" /> Been through the tunnel?
          </p>
          <SplitReveal as="h2" className="display mt-8 text-[clamp(40px,5vw,68px)] text-ink">
            Tell Memphis
            <br />
            <span className="text-orange">how it went.</span>
          </SplitReveal>
          <Reveal className="mt-6 max-w-[480px] text-lg text-smoke">
            <p>Reviews help other drivers and teams find us — and keep our crew sharp. It takes 30 seconds.</p>
          </Reveal>
          <Reveal className="mt-9 flex flex-wrap gap-4">
            <Button href="https://g.page/grindcitydetail/review" variant="dark">
              Review us on Google
            </Button>
            <Button href={site.social.instagram} variant="outline-dark">
              Share on Instagram
            </Button>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
