import "server-only";
import { createClient, type QueryParams } from "@sanity/client";
import { env, sanityEnabled } from "@/env";

export const REVALIDATE_TAG = "sanity";

const client = sanityEnabled
  ? createClient({
      projectId: env.NEXT_PUBLIC_SANITY_PROJECT_ID,
      dataset: env.NEXT_PUBLIC_SANITY_DATASET,
      apiVersion: env.NEXT_PUBLIC_SANITY_API_VERSION,
      useCdn: !env.SANITY_API_READ_TOKEN,
      token: env.SANITY_API_READ_TOKEN,
      perspective: "published",
      maxRetries: 0, // fail fast; the data cache + static fallback cover us
    })
  : null;

/** Circuit breaker: after a failed call, skip Sanity for a minute so an outage never slows pages. */
let downUntil = 0;
const BREAKER_MS = 60_000;

/**
 * Cached GROQ fetch. Results live in Next's data cache for an hour and are purged instantly by
 * the Sanity webhook hitting /api/revalidate. Returns `null` when Sanity isn't configured or
 * the request fails, so every caller falls back to the static data layer.
 */
export async function sanityFetch<T>(query: string, params: QueryParams = {}, tags: string[] = []): Promise<T | null> {
  if (!client || Date.now() < downUntil) return null;
  try {
    return await client.fetch<T>(query, params, {
      signal: AbortSignal.timeout(2500),
      next: { revalidate: 3600, tags: [REVALIDATE_TAG, ...tags] },
    });
  } catch (err) {
    downUntil = Date.now() + BREAKER_MS;
    console.error("[sanity] fetch failed — using static fallback for 60s:", err instanceof Error ? err.message : err);
    return null;
  }
}

/** Write client for server-side mutations (lead capture). */
export const writeClient =
  sanityEnabled && env.SANITY_API_WRITE_TOKEN
    ? createClient({
        projectId: env.NEXT_PUBLIC_SANITY_PROJECT_ID,
        dataset: env.NEXT_PUBLIC_SANITY_DATASET,
        apiVersion: env.NEXT_PUBLIC_SANITY_API_VERSION,
        useCdn: false,
        token: env.SANITY_API_WRITE_TOKEN,
      })
    : null;
