export type SanityImage = { asset?: { _id: string; url: string; metadata?: { dimensions?: { width: number; height: number } } }; alt?: string };

export type Seo = {
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: SanityImage;
  canonicalUrl?: string;
  noIndex?: boolean;
  noFollow?: boolean;
};

export type SiteSettings = {
  siteName?: string;
  tagline?: string;
  description?: string;
  phone?: string;
  email?: string;
  city?: string;
  region?: string;
  hours?: { popups?: string; weekdays?: string };
  social?: { instagram?: string; tiktok?: string; facebook?: string };
  rating?: { value?: number; count?: number };
  seo?: Seo;
  titleTemplate?: string;
  twitterHandle?: string;
  googleSiteVerification?: string;
};

export type PageSeo = { title?: string; seo?: Seo };
