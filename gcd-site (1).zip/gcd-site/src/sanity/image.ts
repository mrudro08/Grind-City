import { createImageUrlBuilder, type SanityImageSource } from "@sanity/image-url";
import { env, sanityEnabled } from "@/env";

const builder = sanityEnabled ? createImageUrlBuilder({ projectId: env.NEXT_PUBLIC_SANITY_PROJECT_ID!, dataset: env.NEXT_PUBLIC_SANITY_DATASET }) : null;

/** Absolute URL for a Sanity image, sized for Open Graph by default. */
export function sanityImageUrl(source: SanityImageSource | undefined, width = 1200, height = 630) {
  if (!builder || !source) return null;
  return builder.image(source).width(width).height(height).fit("crop").auto("format").url();
}
