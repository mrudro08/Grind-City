/** Identity tag so editors get GROQ syntax highlighting. */
const groq = (strings: TemplateStringsArray, ...values: unknown[]) => strings.reduce((acc, str, i) => acc + str + (values[i] ?? ""), "");

/** Fields every SEO-bearing document exposes (see studio/schemas/objects/seo.ts). */
export const seoFields = groq`
  "seo": seo{
    metaTitle,
    metaDescription,
    keywords,
    ogTitle,
    ogDescription,
    ogImage{ asset->{ _id, url, metadata{ dimensions } }, alt },
    canonicalUrl,
    noIndex,
    noFollow
  }
`;

export const siteSettingsQuery = groq`*[_type == "siteSettings"][0]{
  siteName, tagline, description, phone, email, city, region,
  hours, social, rating,
  ${seoFields},
  titleTemplate, twitterHandle, googleSiteVerification
}`;

export const pageSeoQuery = groq`*[_type == "page" && slug.current == $slug][0]{ title, ${seoFields} }`;
