// Static stand-ins for Sanity `review`, `washPackage`, `fleetPlan`, `faq`, `crewMember` and `stat` documents.
// Copy marked PLACEHOLDER must be confirmed or replaced by the client before launch.

export type Review = {
  id: string;
  category: "pop-up" | "employers" | "fleet";
  quote: string;
  name: string;
  role: string;
  rating: number;
  featured?: boolean;
};

export const reviews: Review[] = [
  {
    id: "r1",
    category: "pop-up",
    quote: "In and out while I shot hoops with my kid. Truck hasn't looked this good since I bought it.",
    name: "Brianna Taylor",
    role: "Weekend customer · Midtown",
    rating: 5,
  },
  {
    id: "r2",
    category: "employers",
    quote: "Our team still talks about it. 40 cars washed before lunch and zero work missed. Booking again next month.",
    name: "Marcus Johnson",
    role: "HR Manager · Company",
    rating: 5,
    featured: true,
  },
  {
    id: "r3",
    category: "fleet",
    quote: "Every van looks the part now. The photo report each week makes it easy to show the owners.",
    name: "Tasha Williams",
    role: "Fleet Manager · Company",
    rating: 5,
  },
  {
    id: "r4",
    category: "pop-up",
    quote: "The vibe is unreal — music, games, and the crew actually cares about the details.",
    name: "Derrick Brown",
    role: "Weekend customer · Cordova",
    rating: 5,
  },
  {
    id: "r5",
    category: "employers",
    quote: "Easiest perk we've ever run. They set up, washed everyone's car and left the lot spotless.",
    name: "Keisha Moore",
    role: "Office Manager · Company",
    rating: 5,
  },
  {
    id: "r6",
    category: "pop-up",
    quote: "Found them on a Saturday, came back the next two weekends. Hand wash, no swirl marks.",
    name: "Andre Davis",
    role: "Weekend customer · Germantown",
    rating: 5,
  },
];

export const ratingBreakdown = [
  { stars: 5, pct: 90 },
  { stars: 4, pct: 7 },
  { stars: 3, pct: 2 },
  { stars: 2, pct: 1 },
  { stars: 1, pct: 0 },
];

export type WashPackage = {
  id: string;
  n: string;
  name: string;
  blurb: string;
  price: string;
  features: string[];
  popular?: boolean;
};

export const washPackages: WashPackage[] = [
  {
    id: "express",
    n: "01",
    name: "Express",
    blurb: "Quick exterior refresh between details.",
    price: "$00",
    features: ["Hand wash & rinse", "Hand dry", "Wheel face clean", "Tire shine"],
  },
  {
    id: "signature",
    n: "02",
    name: "Signature",
    blurb: "Our most-booked wash. In, out, shining.",
    price: "$00",
    popular: true,
    features: [
      "Everything in Express",
      "Wheels & wells deep clean",
      "Windows inside & out",
      "Spray wax finish",
      "Quick interior wipe-down",
    ],
  },
  {
    id: "full-shine",
    n: "03",
    name: "Full Shine",
    blurb: "The works — for when it needs it.",
    price: "$00",
    features: [
      "Everything in Signature",
      "Interior vacuum",
      "Bug & tar removal",
      "Ceramic spray sealant",
      "Door jambs",
    ],
  },
];

export const addOns = ["Pet hair removal +$00", "Engine bay wipe +$00", "Headlight restore +$00", "Air freshener +$00"];

export type FleetPlan = { id: string; name: string; blurb: string; price: string; features: string[]; popular?: boolean };

export const fleetPlans: FleetPlan[] = [
  {
    id: "weekly",
    name: "Weekly",
    blurb: "For customer-facing fleets that need to look sharp every day.",
    price: "$00",
    features: ["Every week, same day", "Photo log per vehicle", "Priority rescheduling", "Dedicated crew lead"],
  },
  {
    id: "bi-weekly",
    name: "Bi-weekly",
    blurb: "Our most popular plan for service and delivery fleets.",
    price: "$00",
    popular: true,
    features: ["Every other week", "Photo log per vehicle", "Monthly invoice · ACH", "Client portal access"],
  },
  {
    id: "monthly",
    name: "Monthly",
    blurb: "Keep heavy equipment and trailers presentable.",
    price: "$00",
    features: ["Once a month", "Photo log per vehicle", "Monthly invoice · ACH", "Add-on wheel & undercarriage"],
  },
];

export const vehicles = [
  { n: "01", name: "Box trucks", blurb: "12–26 ft straight trucks", img: "/images/veh-box-truck.webp" },
  { n: "02", name: "Cargo vans", blurb: "Sprinter, Transit, ProMaster", img: "/images/veh-cargo-van.webp" },
  { n: "03", name: "Pickups", blurb: "Work trucks & service bodies", img: "/images/veh-pickup.webp" },
  { n: "04", name: "Tractors", blurb: "Day cabs & sleepers", img: "/images/veh-tractor.webp" },
  { n: "05", name: "Equipment", blurb: "Trailers, lifts & more", img: "/images/veh-equipment.webp" },
];

export type Faq = { q: string; a: string; pages: string[] };

export const faqs: Faq[] = [
  {
    q: "Do I need to book for a weekend pop-up?",
    a: "Nope. Find this weekend's lot, scan the QR code at the tunnel and join the queue. We'll text you when your car is ready.",
    pages: ["home", "pop-up"],
  },
  {
    q: "How much does a wash cost?",
    a: "PLACEHOLDER — Packages start from $00. Final price depends on vehicle size and the add-ons you pick at the tunnel.",
    pages: ["home", "pop-up"],
  },
  {
    q: "How long does it take?",
    a: "PLACEHOLDER — Most washes take 20–30 minutes once you're in the tunnel. Grab a seat in the lounge; we'll text you.",
    pages: ["home", "pop-up"],
  },
  {
    q: "What happens if it rains?",
    a: "PLACEHOLDER — We post updates by 8am on Instagram and text everyone on the pop-up list.",
    pages: ["home", "pop-up"],
  },
  {
    q: "Can you come to our workplace?",
    a: "Yes — that's our Employee Appreciation Day. We bring the pod, the crew, water and power to your lot. Booked pop-ups start with a 30-car minimum.",
    pages: ["home", "pop-up"],
  },
  {
    q: "How does fleet washing work?",
    a: "Tell us your vehicles, yard and frequency. We quote within a business day, lock in your wash day and send one monthly invoice.",
    pages: ["home"],
  },
  {
    q: "Do you need water or power on site?",
    a: "Not necessarily. We can work off your spigot or bring our own water and power — tell us in the quote and we'll plan for it.",
    pages: ["fleet"],
  },
  { q: "What about wastewater and runoff?", a: "PLACEHOLDER — Client to supply answer.", pages: ["fleet"] },
  { q: "Can you wash at night or on weekends?", a: "PLACEHOLDER — Client to supply answer.", pages: ["fleet"] },
  { q: "Do you wash interiors?", a: "PLACEHOLDER — Client to supply answer.", pages: ["fleet"] },
  { q: "How is pricing calculated?", a: "PLACEHOLDER — Client to supply answer.", pages: ["fleet"] },
  { q: "Can we add or remove vehicles month to month?", a: "PLACEHOLDER — Client to supply answer.", pages: ["fleet"] },
];

export const crew = [
  { name: "Marcus Johnson", role: "Founder & Crew Lead" },
  { name: "Tasha Williams", role: "Operations" },
  { name: "Derrick Brown", role: "Fleet Lead" },
  { name: "Keisha Moore", role: "Events & Employers" },
];

export const stats = [
  { value: 12, suffix: "K+", label: "Cars washed", sub: "and counting", pct: 82 },
  { value: 140, suffix: "+", label: "Pop-ups run", sub: "weekends + workplaces", pct: 64 },
  { value: 4.9, suffix: "★", label: "Google rating", sub: "from 312 reviews", pct: 98, decimals: 1 },
  { value: 28, suffix: "+", label: "Fleets & employers", sub: "on recurring schedules", pct: 46 },
];

export const experience = [
  {
    n: "01",
    title: "The 40-ft wash tunnel",
    blurb: "Our branded hand-wash tunnel. Real crew, real mitts — no brushes, no scratches.",
    tag: "Hand wash only",
    img: "/images/exp-tunnel.webp",
  },
  { n: "02", title: "The lounge", blurb: "Shade, seats and good music while the crew works.", tag: "Pull up a chair", img: "/images/exp-lounge.webp" },
  { n: "03", title: "Shootout", blurb: "Sink your shots, win a free wash.", tag: "Win a free wash", img: "/images/exp-shootout.webp", hot: true },
  { n: "04", title: "Giant Connect 4", blurb: "Settle it while you wait.", img: "/images/exp-connect4.webp" },
];

export const services = [
  {
    n: "01",
    title: "Pop-up weekends",
    blurb: "Pull in, hang out, leave shining. Fri–Sun in lots across Memphis.",
    bullets: ["Fri–Sun in high-traffic lots", "No appointment — just pull in", "Lounge, shootout & Connect 4"],
    cta: "Find this weekend",
    href: "/pop-up",
    img: "/images/iso-popup.webp",
  },
  {
    n: "02",
    title: "Employee Appreciation Day",
    blurb: "We bring the pod to your workplace — the tunnel, the lounge, the games.",
    bullets: ["We bring crew, water & power", "Three ways to pay", "30-car minimum"],
    cta: "For employers",
    href: "/employers",
    img: "/images/iso-employer.webp",
    hot: true,
  },
  {
    n: "03",
    title: "Fleet washing",
    blurb: "Recurring exterior washes at your yard. Trucks and equipment only.",
    bullets: ["Weekly, bi-weekly or monthly", "Photo log of every wash", "One monthly invoice"],
    cta: "Get a fleet quote",
    href: "/fleet",
    img: "/images/iso-fleet.webp",
  },
];

export const payOptions = [
  {
    n: "01",
    title: "Employer-paid",
    body: "The company covers the day for the team — and the team gets the full experience, wash, lounge, and games. That's the employer rewarding their associates.",
    includes: { wash: true, lounge: true, games: true },
  },
  {
    n: "02",
    title: "Shared cost",
    body: "The company covers part, associates cover the rest. Associates get the wash, and can ask for the full experience.",
    includes: { wash: true, lounge: false, games: false },
  },
  {
    n: "03",
    title: "Associate-paid",
    body: "We set up on your lot, associates pay for their own wash, and can ask for the full experience.",
    includes: { wash: true, lounge: false, games: false },
  },
];

export const employerSteps = [
  { n: "01", text: "Call us to pick a date.", img: "/images/emp-step-1.webp" },
  { n: "02", text: "We bring everything — crew, water, power — and set up the pod on your lot.", img: "/images/emp-step-2.webp" },
  { n: "03", text: "Your team pulls in during the day and drives out clean.", img: "/images/emp-step-3.webp", hot: true },
  { n: "04", text: "We break down and leave the lot clean.", img: "/images/emp-step-4.webp" },
];
