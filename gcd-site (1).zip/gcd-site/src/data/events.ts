// Static stand-in for Sanity `popupEvent` documents.
export type PopupEvent = {
  slug: string;
  lot: string;
  area: string;
  address: string;
  start: string; // ISO date
  end: string;
  dateLabel: string;
  hours: { day: string; time: string }[];
  status: "live" | "confirmed" | "tentative";
  mapUrl: string;
};

export const events: PopupEvent[] = [
  {
    slug: "union-ave-plaza-oct-30",
    lot: "Union Ave Plaza",
    area: "Midtown",
    address: "1820 Union Ave, Memphis, TN 38104",
    start: "2026-10-30",
    end: "2026-11-01",
    dateLabel: "Oct 30 – Nov 1",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "live",
    mapUrl: "https://maps.google.com/?q=1820+Union+Ave+Memphis+TN",
  },
  {
    slug: "poplar-pike-commons-nov-6",
    lot: "Poplar Pike Commons",
    area: "Germantown",
    address: "7690 Poplar Pike, Germantown, TN 38138",
    start: "2026-11-06",
    end: "2026-11-08",
    dateLabel: "Nov 6 – 8",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "confirmed",
    mapUrl: "https://maps.google.com/?q=7690+Poplar+Pike+Germantown+TN",
  },
  {
    slug: "trinity-commons-nov-13",
    lot: "Trinity Commons",
    area: "Cordova",
    address: "8045 Trinity Rd, Cordova, TN 38018",
    start: "2026-11-13",
    end: "2026-11-15",
    dateLabel: "Nov 13 – 15",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "confirmed",
    mapUrl: "https://maps.google.com/?q=8045+Trinity+Rd+Cordova+TN",
  },
  {
    slug: "riverside-lot-b-nov-20",
    lot: "Riverside Lot B",
    area: "Downtown",
    address: "215 Riverside Dr, Memphis, TN 38103",
    start: "2026-11-20",
    end: "2026-11-22",
    dateLabel: "Nov 20 – 22",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "confirmed",
    mapUrl: "https://maps.google.com/?q=215+Riverside+Dr+Memphis+TN",
  },
  {
    slug: "white-station-plaza-nov-27",
    lot: "White Station Plaza",
    area: "East Memphis",
    address: "4530 Poplar Ave, Memphis, TN 38117",
    start: "2026-11-27",
    end: "2026-11-29",
    dateLabel: "Nov 27 – 29",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "tentative",
    mapUrl: "https://maps.google.com/?q=4530+Poplar+Ave+Memphis+TN",
  },
  {
    slug: "union-ave-plaza-dec-4",
    lot: "Union Ave Plaza",
    area: "Midtown",
    address: "1820 Union Ave, Memphis, TN 38104",
    start: "2026-12-04",
    end: "2026-12-06",
    dateLabel: "Dec 4 – 6",
    hours: [
      { day: "Fri", time: "3:00 – 8:00 PM" },
      { day: "Sat", time: "9:00 AM – 6:00 PM" },
      { day: "Sun", time: "11:00 AM – 5:00 PM" },
    ],
    status: "tentative",
    mapUrl: "https://maps.google.com/?q=1820+Union+Ave+Memphis+TN",
  },
];

export const thisWeekend = events[0];
export const upcoming = events.slice(1);
export const areas = ["All areas", ...Array.from(new Set(events.map((e) => e.area)))];
