// Static stand-in for the Sanity `siteSettings` singleton.
// All values here are placeholders until the client supplies real details.
export const site = {
  name: "Grind City Detail",
  tagline: "Grind hard. Shine harder.",
  description:
    "Memphis' mobile hand car wash. Weekend pop-ups across the city, Employee Appreciation Days at your workplace and recurring fleet washing at your yard.",
  url: "https://grindcitydetail.com",
  phone: "(901) 555-0142",
  phoneHref: "tel:+19015550142",
  email: "hello@grindcitydetail.com",
  city: "Memphis",
  region: "TN",
  hours: {
    popups: "Fri–Sun: pop-ups",
    weekdays: "Mon–Thu: workplaces & fleets",
  },
  social: {
    instagram: "https://instagram.com/grindcitydetail",
    tiktok: "https://tiktok.com/@grindcitydetail",
    facebook: "https://facebook.com/grindcitydetail",
  },
  rating: { value: 4.9, count: 312 },
};

export const nav = [
  { label: "Pop-Up", href: "/pop-up" },
  { label: "Fleet", href: "/fleet" },
  { label: "Employers", href: "/employers" },
  { label: "Reviews", href: "/reviews" },
  { label: "About", href: "/about" },
];

export const footerColumns = [
  {
    title: "Pop-Up",
    links: [
      { label: "This weekend", href: "/pop-up#this-weekend" },
      { label: "Wash menu", href: "/pop-up#menu" },
      { label: "Upcoming dates", href: "/pop-up#upcoming" },
    ],
  },
  {
    title: "Fleet",
    links: [
      { label: "How it works", href: "/fleet#how" },
      { label: "Plans", href: "/fleet#plans" },
      { label: "Get a quote", href: "/fleet#quote" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "Employers", href: "/employers" },
      { label: "About", href: "/about" },
      { label: "Reviews", href: "/reviews" },
    ],
  },
];
