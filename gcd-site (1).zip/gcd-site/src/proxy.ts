import { NextRequest, NextResponse } from "next/server";

/**
 * Per-request security proxy.
 * - Generates a CSP nonce, passes it to the renderer (x-nonce) and sets a strict CSP.
 * - script-src uses 'strict-dynamic' + nonce: only scripts Next emits with the nonce run,
 *   anything injected (XSS) is blocked.
 * - style-src keeps 'unsafe-inline' because GSAP/React write inline style attributes; this is
 *   the accepted trade-off for animation-heavy sites and does not enable script execution.
 */
export function proxy(request: NextRequest) {
  const nonce = Buffer.from(crypto.randomUUID()).toString("base64");
  const isDev = process.env.NODE_ENV === "development";

  const sanityProject = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID;
  const sanityHosts = sanityProject ? `https://${sanityProject}.api.sanity.io https://${sanityProject}.apicdn.sanity.io https://cdn.sanity.io` : "";

  const csp = [
    `default-src 'self'`,
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${isDev ? " 'unsafe-eval'" : ""}`,
    `style-src 'self' 'unsafe-inline'`,
    `img-src 'self' blob: data: https://cdn.sanity.io https://maps.googleapis.com https://maps.gstatic.com`,
    `font-src 'self'`,
    `connect-src 'self' ${sanityHosts}${isDev ? " ws: wss:" : ""}`,
    `media-src 'self'`,
    `object-src 'none'`,
    `base-uri 'self'`,
    `form-action 'self'`,
    `frame-ancestors 'none'`,
    `manifest-src 'self'`,
    `worker-src 'self' blob:`,
    isDev ? "" : `upgrade-insecure-requests`,
  ]
    .filter(Boolean)
    .join("; ");

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-nonce", nonce);
  requestHeaders.set("Content-Security-Policy", csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set("Content-Security-Policy", csp);
  return response;
}

export const config = {
  matcher: [
    {
      // Everything except API routes, static assets and prefetches
      source: "/((?!api|_next/static|_next/image|images|fonts|favicon.ico|robots.txt|sitemap.xml).*)",
      missing: [
        { type: "header", key: "next-router-prefetch" },
        { type: "header", key: "purpose", value: "prefetch" },
      ],
    },
  ],
};
